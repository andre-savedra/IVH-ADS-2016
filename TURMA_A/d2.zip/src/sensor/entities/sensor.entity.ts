export class Sensor {}
